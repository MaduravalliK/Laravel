<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
   // use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['title', 'body', 'created_at','udated_at'];

    public function saveArticle($data)
{
        $this->user_id = 1; //auth()->user()->id;
        $this->title = $data['title'];
        $this->body = $data['body'];
        $this->save();
        return 1;
}

public function updateArticle($data)
{	print_r($data);
        $ticket = $this->find($data['id']);
        $ticket->user_id = 1;//auth()->user()->id;
        $ticket->title = $data['title'];
        $ticket->body = $data['body'];
        $ticket->save();
        return 1;
}

}
