<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Article;
 
class ArticleController extends Controller
{
    /*public function index()
    {
        return Article::all();
    }*/
	
	public function index()
    {
        $tickets = Article::all();//Article::where('user_id', auth()->user()->id)->get();
        
        return view('user.index',compact('tickets'));
    }


		public function create()
		{
		   return view('article.create');
		}

    public function show(Article $article)
    {
        return $article;
    }

    /*public function store(Request $request)
    {
        $article = Article::create($request->all());

        return response()->json($article, 201);
    }*/
	
	public function store(Request $request)
    {
        $ticket = new Article();
        $data = $this->validate($request, [
            'body'=>'required',
            'title'=> 'required'
        ]);
       
        $ticket->saveArticle($data);
        return redirect('/tickets')->with('success', 'New support ticket has been created! Wait sometime to get resolved');
    }
	
	public function edit($id)
    {
        $ticket = Article::where('user_id', 1)
                        ->where('id', $id)
                        ->first();

        return view('article.edit', compact('ticket', 'id'));
    }

    /*public function update(Request $request, Article $article)
    {
        $article->update($request->all());

        return response()->json($article, 200);
    }*/
	
	public function update(Request $request, $id)
    {
        $ticket = new Article();
        $data = $this->validate($request, [
            'body'=>'required',
            'title'=> 'required'
        ]);
        $data['id'] = $id;
        $ticket->updateArticle($data);

        return redirect('/tickets')->with('success', 'New support ticket has been updated!!');
    }
	
	public function updates(Request $request)
    {
        $ticket = new Article();
        $data = $this->validate($request, [
			'id'=>'required',
            'body'=>'required',
            'title'=> 'required'
        ]);
       // $data['id'] = $id;
        $ticket->updateArticle($data);

        return redirect('/tickets')->with('success', 'New support ticket has been updated!!');
    }


    public function delete(Article $article)
    {
        $article->delete();

        return response()->json(null, 204);
    }
	
	public function destroy($id)
    {
        $ticket = Article::find($id);
        $ticket->delete();

        return redirect('/tickets')->with('success', 'Ticket has been deleted!!');
    }
	
}