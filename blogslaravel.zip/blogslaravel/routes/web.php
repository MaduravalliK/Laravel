<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/create/ticket','ArticleController@create');
Route::post('/create/ticket','ArticleController@store');
Route::get('/tickets', 'ArticleController@index');
Route::get('/edit/ticket/{id}','ArticleController@edit');
Route::post('/edit/ticket/{id}','ArticleController@update');
Route::delete('/delete/ticket/{id}','ArticleController@destroy');


Route::post('api/login', 'LoginControllerAPI@login')->name('api.login');
Route::post('api/logout', 'LoginControllerAPI@logout')->name('api.logout');